package com.demo.stockExchangeApplication.service;

import com.demo.stockExchangeApplication.model.User;

public interface UserService {

	public User registerUser(User user);
}
