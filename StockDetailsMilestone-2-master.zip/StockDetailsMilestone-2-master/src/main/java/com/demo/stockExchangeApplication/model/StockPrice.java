package com.demo.stockExchangeApplication.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="stockprice")
public class StockPrice {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int stockId;	
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="company_code")
	private Company company;
	
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="stockexchange_id")
	private StockExchange StockExchange;
	
	private double currentPrice;
	private Date date;
	private String time;
	public int getStockId() {
		return stockId;
	}
	public void setStockId(int stockId) {
		this.stockId = stockId;
	}
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}
	public StockExchange getStockExchange() {
		return StockExchange;
	}
	public void setStockExchange(StockExchange stockExchange) {
		StockExchange = stockExchange;
	}
	public double getCurrentPrice() {
		return currentPrice;
	}
	public void setCurrentPrice(double currentPrice) {
		this.currentPrice = currentPrice;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public StockPrice(int stockId, com.demo.stockExchangeApplication.model.Company company,
			com.demo.stockExchangeApplication.model.StockExchange stockExchange, double currentPrice, Date date,
			String time) {
		super();
		this.stockId = stockId;
		this.company = company;
		StockExchange = stockExchange;
		this.currentPrice = currentPrice;
		this.date = date;
		this.time = time;
	}
	public StockPrice() {
		// TODO Auto-generated constructor stub
	}
	
}
