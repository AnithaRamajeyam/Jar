package com.demo.stockExchangeApplication.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.demo.stockExchangeApplication.model.Company;

public interface CompanyDao extends JpaRepository<Company, Integer> {

	List<Company> findBySectorId(int sectorid);

    @Query(value="SELECT * FROM Company c Where c.company_name LIKE %?% ", nativeQuery=true)
	List<Company> findAllByCompanyName(String name);

	Company findByCompanyName(String name);
	
}
